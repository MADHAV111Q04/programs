#include <stdio.h>
int main(){int n,i,j,f;scanf("%d",&n);for(i=2;i<=n;i++){f=0;for(j=2;j<=i/2;j++)if(i%j==0){f=1;break;}if(!f)printf("%d ",i);}return 0;}