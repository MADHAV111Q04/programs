#include <stdio.h>
int main(){float l,b;scanf("%f%f",&l,&b);printf("%.2f %.2f",l*b,2*(l+b));return 0;}