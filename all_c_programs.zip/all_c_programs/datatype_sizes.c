#include <stdio.h>
int main(){printf("%lu %lu %lu %lu",sizeof(int),sizeof(float),sizeof(double),sizeof(char));return 0;}