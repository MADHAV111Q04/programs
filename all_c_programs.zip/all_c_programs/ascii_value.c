#include <stdio.h>
int main(){char c;scanf("%c",&c);printf("%d",c);return 0;}